# @mowa-bot/react

React components for [Mowa Bot](https://mowa-bot.vercel.app), a procedural character engine
for the web: a roster of generated characters and a named cast, ink colours, animation states,
sixteen faces, vector, pixel, kaomoji and ASCII styles and an SVG HUD, all drawn by code and
animated from one shared frame loop. Try them in the [console](https://mowa-bot.vercel.app/en/).

## Install

```bash
pnpm add @mowa-bot/react
```

Requires React 19. `@mowa-bot/engine` is a dependency and comes along automatically.

## First character

```tsx
import { CharacterMark } from '@mowa-bot/react';
import '@mowa-bot/react/styles.css';

export function Hero() {
  return <CharacterMark shape="mochi" state="happy" sizePx={120} />;
}
```

Import the stylesheet once, at the root of the application. It lives in a CSS `@layer`, so
your own rules win without `!important`.

## Components

| Component                                                                 | Use it for                                                                  |
| ------------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| `CharacterMark`                                                           | One animated character; `styleId`, `variant`, `face`, `hud`, `followTarget` |
| `CharacterStageProvider` + `StagedMark`                                   | Many characters sharing a few engines; falls back to still images           |
| `useMarkCommands`, `useMarkCommand`, `useMarkSettle`, `useTapCycle`       | Hold a state, wait for settle, poke an agent from anywhere in the tree      |
| `CharacterMarkMirror`                                                     | Re-drawing a running character elsewhere via `<use href>`                   |
| `AgentPortrait`, `AvatarGroup`, `GroupAvatar`                             | A stable character per user, derived from any id                            |
| `UnreadBadge`, `AvatarStatusDot`, `WorkingBadge`                          | Avatar decorations                                                          |
| `CharacterSelector`, `AgentCharacterSelector`, `CompactCharacterSelector` | Letting users choose a shape, colour, face and nose                         |
| `AvatarStudio`, `AvatarButton`, `AvatarField`                             | Character or cropped picture, in a dialog or inline                         |
| `ActivityBadge`, `GroupActivityBadge`                                     | "Someone is working" indicators, with facts, bubbles and poke               |
| `ActivityLine`                                                            | Crossfading one-line status text                                            |
| `HudPlate`, `AgentHud`, `useHudSpec`                                      | Progress, timers, waveforms, KPIs and more drawn around the character       |
| `AgentStateProvider`, `useArbiter`, `useAgentHud`                         | Multi-session emotion protocol → one displayed state and HUD                |
| `useStateChannel`, `useEventSourceChannel`                                | Feeding that protocol from a `postMessage` port or an SSE stream            |
| `useIdleSleep`                                                            | Letting an unattended character drowse and then fall asleep                 |
| `SpriteMark`                                                              | Painted sprite sheet keyed by the same protocol ids                         |
| `CelebrationLayer`                                                        | Celebration without a character attached                                    |
| `LocaleProvider`, `useLabel`                                              | Component copy and catalogue labels in `en-US` or `zh-CN`                   |

Onboarding walkthroughs, scenes, the template dialog, the occupancy list and the cast lineup
live in [`@mowa-bot/surfaces`](https://github.com/ShmilyXI/mowa-bot/tree/main/packages/surfaces),
which builds on this package.

## Server rendering

`@mowa-bot/react/static` contains only what can run without a DOM, and carries no
`'use client'` banner, so it is usable from a React Server Component. That is: the
static rendering functions (`renderStaticSvg`, `renderStaticSvgDataUrl`,
`renderAvatarDataUrl`, `shapeMaskImage`, `shapeRingMaskImage`), the
deterministic id hashing (`autoShapeForKey`, `autoColorForKey`,
`autoNoseForKey`), the identifier and cast tables, the crop arithmetic
(`fitImage`, `clampPan`, `clampZoom`, `exportPlacement` and their limits — but
not `cropToDataUrl`, `loadImage` or `readImageFile`, which need a canvas), and
both locale tables (`enUS`, `zhCN`) so a server can render the copy in either
language.

```tsx
import { renderAvatarDataUrl } from '@mowa-bot/react/static';

export default function Page() {
  return <img src={renderAvatarDataUrl('ada@example.com')} width={40} height={40} alt="" />;
}
```

## Documentation

- [Getting started](https://mowa-bot.vercel.app/en/guide/getting-started)
- [Component overview](https://mowa-bot.vercel.app/en/components/overview)
- [Performance: hundreds of characters](https://mowa-bot.vercel.app/en/guide/performance)
- [Server rendering](https://mowa-bot.vercel.app/en/guide/server-rendering)

## License

[MIT](https://github.com/ShmilyXI/mowa-bot/blob/main/LICENSE), code and character designs alike. Based on [Aora Bot](https://github.com/sam70361/aora-bot) by sam70361 (MIT); see [NOTICE.md](https://github.com/ShmilyXI/mowa-bot/blob/main/NOTICE.md).
